package com.inventory.model;

import java.util.Map;

public class Catalogue{
    private Category category;
    private Map<Product, Integer> productCount;
    private Map<String, Product> productMap;

}


