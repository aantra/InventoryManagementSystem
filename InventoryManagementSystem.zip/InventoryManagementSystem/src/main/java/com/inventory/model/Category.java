package com.inventory.model;
public enum Category {
    ELECTRONICS,
    APPAREL
};