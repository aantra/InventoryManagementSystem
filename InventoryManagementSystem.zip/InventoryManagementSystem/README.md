## Assumptions ## 
product id and product name both are unique